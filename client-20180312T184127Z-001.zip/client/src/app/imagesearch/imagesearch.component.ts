import { Component, OnInit } from '@angular/core';
import { ImagesearchService } from './imagesearch.service'

@Component({
  selector: 'app-imagesearch',
  templateUrl: './imagesearch.component.html',
  styleUrls: ['./imagesearch.component.css'],
  providers:[ ImagesearchService ]
})
export class ImagesearchComponent implements OnInit {
keyword:any;
img:any;
ref:any;
val:any;
  constructor(private imagesearchservice:ImagesearchService) { }

  ngOnInit() {
  }

  getimage(keyword){
  	this.imagesearchservice.getimage(keyword)
  	.subscribe((res)=>{
  		this.img=res;
  	})
    this.storekeyword(keyword);
  }
   getkeyword(){
    this.imagesearchservice.getkeyword()
    .subscribe((res)=>{
      console.log("in getkeyword",res.data);
      this.img=res.data;
    })
  }
   storekeyword(keyword){
    this.imagesearchservice.storekeyword(keyword)
    .subscribe((res)=>{
      console.log("in storekeyword",res.data);
      this.ref=res;
    })
  }
  onclick(value){
    this.val=value;
  }
}
