import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/observable';
import { Http,Response } from '@angular/http';
import 'rxjs/add/operator/map';


@Injectable()
export class ImagesearchService {

  constructor(private http:Http) { }

  getimage(keyword):Observable<any>{
  	let url="http://localhost:3000/find_image";
  	return this.http
  	.get(url,keyword)
  	.map((res)=>res.json())
  }

  getkeyword():Observable<any>{
  	let url="http://localhost:3000/get_keyword";
  	return this.http
  	.get(url)
  	.map((res)=>res.json())
  }

  storekeyword(keyword):Observable<any>{
    console.log(keyword)
  	let url="http://localhost:3000/insert_keyword";
  	return this.http
  	.post(url,{keyword:keyword})
  	.map((res)=>res.json())
  }
}
