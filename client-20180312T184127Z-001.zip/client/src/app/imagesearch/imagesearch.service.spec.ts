import { TestBed, inject } from '@angular/core/testing';

import { ImagesearchService } from './imagesearch.service';

describe('ImagesearchService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ImagesearchService]
    });
  });

  it('should be created', inject([ImagesearchService], (service: ImagesearchService) => {
    expect(service).toBeTruthy();
  }));
});
